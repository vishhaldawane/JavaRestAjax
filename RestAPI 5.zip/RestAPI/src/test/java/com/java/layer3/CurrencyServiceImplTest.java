package com.java.layer3;

import org.junit.jupiter.api.Test;

import com.java.layer2.Currency;
import com.java.layer4.CurrencyAlreadyExistsException;
import com.java.layer4.CurrencyNotFoundException;
import com.java.layer4.CurrencyService;
import com.java.layer4.CurrencyServiceImpl;
import com.java.layer4.SourceCurrencyNotFoundException;
import com.java.layer4.TargetCurrencyNotFoundException;

public class CurrencyServiceImplTest {

	CurrencyService currService = new CurrencyServiceImpl();

	@Test
	public void conversionTest() throws SourceCurrencyNotFoundException, TargetCurrencyNotFoundException, CurrencyNotFoundException {
		
		double convertedAmt = currService.calculateCurrencyService("USD", "EUR", 1200);
		System.out.println("Converted amount : "+convertedAmt);
		
	}
	@Test public void currencyAddTest() {Currency currency = new Currency();
		currency.setSourceCurrency("EUR");currency.setTargetCurrency("IND");currency.setLoadFactor(0.454);	
		try {currService.saveCurrencyService(currency);
		} catch (CurrencyAlreadyExistsException e) {
			System.out.println("Error : "+e);
		}
		
	}
	
	@Test public void currencyModifyTest() {
	Currency currency = new Currency();
	currency.setCurrencyId(21);
	currency.setSourceCurrency("TTT");
	currency.setTargetCurrency("BBB");
	currency.setLoadFactor(0.333);	
	try {currService.modifyCurrencyService(currency);
	} catch (CurrencyNotFoundException e) {
		System.out.println("Error : "+e);
	}
	
}

}
