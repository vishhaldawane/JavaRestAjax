package com.java.layer4;

import java.util.List;

import com.java.layer2.Currency;

public interface CurrencyService {
	void saveCurrencyService(Currency currency) throws CurrencyAlreadyExistsException;
	void modifyCurrencyService(Currency currency) throws CurrencyNotFoundException;
	//void removeCurrencyService(int currencyId);
	/*Currency findCurrencyService(int currencyId);
	List<Currency> findAllAllCurrenciesService();
	*/
	//1
	double calculateCurrencyService(String s,String t, float amt) throws CurrencyNotFoundException,SourceCurrencyNotFoundException, TargetCurrencyNotFoundException;
	
}
