package com.java.layer4;

public class CurrencyAlreadyExistsException extends Exception {

	public CurrencyAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
