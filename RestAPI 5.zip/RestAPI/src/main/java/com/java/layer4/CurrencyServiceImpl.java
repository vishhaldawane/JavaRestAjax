package com.java.layer4;

import java.util.List;

import com.java.layer2.Currency;
import com.java.layer3.CurrencyDAO;
import com.java.layer3.CurrencyDAOImpl;

public class CurrencyServiceImpl implements CurrencyService {

	CurrencyDAO currDao = new CurrencyDAOImpl();
	
	@Override								//   USD	INR		5000
	public double calculateCurrencyService(String s, String t, float amt) throws CurrencyNotFoundException,SourceCurrencyNotFoundException, TargetCurrencyNotFoundException
	{

		List<Currency> listCurrencies = currDao.selectAllCurrencies();
		
		boolean currencyFound=false;
		
		double calculatedAmount=0;
		
		for (Currency currency : listCurrencies) {
			System.out.println("=>Currency : "+currency);
			if(currency.getSourceCurrency().equals(s) && currency.getTargetCurrency().equals(t) ) {
					double currentLoadFactor = currency.getLoadFactor();
					calculatedAmount = amt * currentLoadFactor;		
					currencyFound=true;
					break;
			} else {
				currencyFound=false;
			}
		}
	
		if(currencyFound==false) {
			throw new CurrencyNotFoundException("Currency not found");
		}
		return calculatedAmount;
	}

	public void saveCurrencyService(Currency currencyToAdd) throws CurrencyAlreadyExistsException
	{
		List<Currency> listCurrencies = currDao.selectAllCurrencies();
		boolean currencyFound=false;	
		for (Currency currency : listCurrencies) {
			if(currency.getSourceCurrency().equals(currencyToAdd.getSourceCurrency()) && currency.getTargetCurrency().equals(currency.getTargetCurrency()) ) {
					currencyFound=true;	break;
			} 
		}
		if(currencyFound==true)throw new CurrencyAlreadyExistsException("Currency alreayd present");
		else currDao.insertCurrency(currencyToAdd);
	}
	
	public void modifyCurrencyService(Currency currencyToModify) throws CurrencyNotFoundException
	{
		List<Currency> listCurrencies = currDao.selectAllCurrencies();
		boolean currencyFound=false;	
		for (Currency currency : listCurrencies) {
			if(currency.getCurrencyId() == currencyToModify.getCurrencyId() ) {
					currencyFound=true;	
					break;
			} 
		}
		if(currencyFound==false)throw new CurrencyNotFoundException("Currency Not present");
		else currDao.updateCurrency(currencyToModify);
	}
}
