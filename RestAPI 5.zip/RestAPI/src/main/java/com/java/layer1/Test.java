package com.java.layer1;

import java.math.BigDecimal;

public class Test {
	public static void main(String[] args) {
		
		double amt1 = 10000000 * 82;
		
		BigDecimal amt2 = new BigDecimal("1.123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890");
		
		System.out.println("amt "+amt1);
		System.out.println("amt "+amt2);
		
	
		
	}
}
