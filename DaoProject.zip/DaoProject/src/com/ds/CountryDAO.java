package com.ds;

import java.util.List;

//poji - plain old java interface
public interface CountryDAO { //separate the low level data access logic
	//CRUD methods 
	
	void saveCountry(Country cnt); //C
	Country findCountry(String primaryKeyCountryName);
	List<Country> findAllCountries();
	void modifyCountry(Country cnt); //U
	void removeCountry(String primaryKeyCountryName); //D
	
	
}
/*											
 
 										1	Database [ kitchen ]
 											|	
								2	FoodRepository [ DAO ]
									|
		Hotel			3		FoodService 
								|
			4		OrderService
					|
			---------
			|
		Rishabh
		   | MENUCARD 5
Sinchit	Table <-- Dinesh
		   |
		 Pawan

*/