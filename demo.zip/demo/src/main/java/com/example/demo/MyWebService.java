package com.example.demo;

import java.util.ArrayList;
import java.util.List;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController

@RequestMapping("/myweb")
public class MyWebService {
	ArrayList<Employee> myList = new ArrayList<Employee>();
	ArrayList<Employee> myList2 = new ArrayList<Employee>();

	public MyWebService() {
		System.out.println("MyWebService() ctor...");
		Employee emoObj1 = new Employee(101,"Jack",1000);
		Employee emoObj2 = new Employee(102,"Jane",2000);
		Employee emoObj3 = new Employee(103,"Jill",3000);
		Employee emoObj4 = new Employee(104,"Julie",4000);
		Employee emoObj5 = new Employee(105,"Janet",5000);
		myList.add(emoObj1);myList.add(emoObj2);
		myList.add(emoObj3);myList.add(emoObj4);
		myList.add(emoObj5);
	}
	@GetMapping("/getEmps")
	public List<Employee> getAllEmployees()
	{
		System.out.println("getAllEmployees() returning the array list..");
		return myList;
	}
	
	
	@GetMapping("/getEmp/{eno}") // http://localhost:8080/myweb/getEmp/101
	public ResponseEntity<?> getEmployee(@PathVariable("eno") int empno) {
		System.out.println("getEmployee() returning the employee...");
		boolean foundEmp = false;
		Employee tempEmp = null;
		for (Employee employee : myList) {
			if(employee.getEmpno()==empno) {
				tempEmp = employee; foundEmp = true; break;
			}
		}
		if(foundEmp==true) {
			return ResponseEntity.ok(tempEmp);
		}
		else {
			EmployeeNotFoundException empNotFndEx = 
					new EmployeeNotFoundException("Employee does not exists...");
			return ResponseEntity.status(404).body(empNotFndEx.getMessage());
		}
	}
	
	@PostMapping("/addEmp") // http://localhost:8080/myweb/addEmp  -> BODY BY POSTMAN
	public ResponseEntity<?> addEmployee(@RequestBody Employee empObj) {
		System.out.println("addEmployee() adding the employee...");
		boolean foundEmp = false; Employee tempEmp = null;
		for (Employee employee : myList) {
			if(employee.getEmpno()==empObj.getEmpno()) {
				tempEmp = employee; foundEmp = true; break;
			}
		}
		if(foundEmp==true) {
			EmployeeAlreadyExistException empExistEx = new 
				EmployeeAlreadyExistException("Employee "
						+ "already exists with this ID "+empObj.getEmpno());
			return ResponseEntity.status(404).body(empExistEx.getMessage());
		}
		else {
			myList.add(empObj);
			return ResponseEntity.ok(empObj);
		}
	}
	
	
	@GetMapping("/greet") // http://localhost:8080/myweb/greet
	public String greeting()
	{
		return "<h2> Welcome to the world of web services </h2>";
	}
	
	@GetMapping("/welcome") // http://localhost:8080/myweb/welcome
	public String welcomeToHome()
	{
		return "<h2> Welcome to the Home of this website </h2>";
	}
}
