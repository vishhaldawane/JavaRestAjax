package com.example.demo;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping("/yourweb")
public class YourWebService {

	@GetMapping("/greet") // http://localhost:8080/yourweb/greet
	public String greeting()
	{
		return "<h2> Welcome to Your web services </h2>";
	}
	
	@GetMapping("/welcome") // http://localhost:8080/yourweb/welcome
	public String welcomeToHome()
	{
		return "<h2> Welcome to Your Home of this website </h2>";
	}
}
