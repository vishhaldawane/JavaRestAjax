package com.example.demo;

public class EmployeeAlreadyExistException extends Exception {
	public EmployeeAlreadyExistException(String msg) {
		super(msg);
	}
}
