package com.java.songs;

public class Song {

	void songPlay() {
	
	
	}
}
