package com.java.bank.accounts;


abstract class BankAccount {//Illegal modifier for the class BankAccount; only public, abstract & final are permitted
	//abstract void withdraw(); // incomplete method | just declared | partial contract
	//private double bankBalance;
}