package com.java.bank.accounts;

public class SuperFlexiFixedDepositAccount extends FlexiFixedDepositAccount {
	void calculateFlexiTerms() { //3. inherited-overriding
		//redifned behaviour here 
	}
}
