package com.java.chess;

public class Chess {
	//overridden
	void moveBishop() { // Camel      Rook Knite Bishop  King Queen   Bishop Knite Rook
								//    pawn  pawn  pawn   pawn  pawn   pawn   pawn  pawn
		System.out.println("moving bishop is diagonal way... bidirectional on one color");
	}
}