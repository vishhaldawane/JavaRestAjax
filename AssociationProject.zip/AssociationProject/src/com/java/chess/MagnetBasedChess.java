package com.java.chess;

public class MagnetBasedChess extends Chess {
	//overriding
	void moveBishop() { 
		System.out.println("on a magetic board...moving bishop is diagonal way... bidirectional on one color");
	}
}