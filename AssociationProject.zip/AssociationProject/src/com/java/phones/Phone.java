package com.java.phones;

public class Phone {

}
