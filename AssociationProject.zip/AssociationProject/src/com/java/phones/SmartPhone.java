package com.java.phones;

class SmartPhone extends Phone {

	void dial() {
		
	}
	void dial(String name) {
		
	}
	void dial(byte number) {
		
	}
}