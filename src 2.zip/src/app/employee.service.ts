import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Emp } from './Emp';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private myHttp: HttpClient) { }
  
  getAllEmployeesService(): Observable<Emp[]> {
    console.log('getAllEmployeesService is invoked...');
    return this.myHttp.get<Emp[]>("http://localhost:8080/myweb/getEmps");
    
  }

}
