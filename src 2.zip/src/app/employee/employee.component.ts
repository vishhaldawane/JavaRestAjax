import { Component, OnInit } from '@angular/core';
import { Emp } from '../Emp';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private empService:EmployeeService) { }

  allEmps!: Emp[]; 
  ngOnInit(): void {
  }

  dummyViewAllStaff() {
    console.log('dummyViewAllStaff() is invoked...');

    this.empService.getAllEmployeesService().subscribe(

    (data: Emp[])=> //srping data is pushed into this data variable
      {
        this.allEmps = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.allEmps);
      }, 
      (err) => {
        console.log(err);
      }
    ); //end of subscribe is here
  }
}
