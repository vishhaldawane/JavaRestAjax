export class Staff {
	  staffid!: number;
	  staffname!: string;
	  staffusername!: string;
	  password!: string;
	  staffstatus!: boolean;
}
