import { Component, OnInit } from '@angular/core';
import { StaffService } from '../staff.service';
import { Staff } from './Staff';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {

  allStaff!: Staff[]; //blannk array as of now

  newStaff: Staff = new Staff(); //blank object for new staff creation

  constructor(private staffService : StaffService) { }

  ngOnInit(): void {
  }

  dummyAddNewStaff() {
    this.newStaff.staffstatus=true;

    console.log('dummyAddNewStaff() invoked...');

    this.staffService.addNewStaffService(this.newStaff).subscribe(

      (data: Staff)=> {
        console.log(data);
        console.log('staff added');
      },
      (err) => {
        console.log(err);
      }

    );

  }

  dummyViewAllStaff() {
    console.log('dummyViewAllStaff() is invoked...');

    this.staffService.getAllStaffService().subscribe(

    (data: Staff[])=> //srping data is pushed into this data variable
      {
        this.allStaff = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.allStaff);
      }, 
      (err) => {
        console.log(err);
      }
    ); //end of subscribe is here
  }
}
