export class Emp {
      empno!: number;
	  name! :string;
	  salary! : number;
	  comm! : number;
	
}