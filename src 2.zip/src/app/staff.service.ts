import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Staff } from './staff/Staff';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StaffService {

  constructor( private myHttp: HttpClient) { }

  getAllStaffService(): Observable<Staff[]> {
    console.log('getAllStaffService is invoked...');
    return this.myHttp.get<Staff[]>("http://localhost:8080/staff/getStaff");
    
  }



  addNewStaffService(newStaffObj: Staff): Observable<Staff> {
    console.log('addNewStaffService is invoked...');
    return this.myHttp.post<Staff>("http://localhost:8080/staff/addStaff",newStaffObj);
    
  }

}
